<?php //This file will be generated automatically
$cdn_commit_version = 'f6722b5';
?>