<?php //此文件内容会由构建工具自动生成
if(get_option('mdx_version_commit')!='2.0.3.20a1c53'){update_option('mdx_version', '2.0.3');update_option('mdx_version_commit', '2.0.3.20a1c53');}?>