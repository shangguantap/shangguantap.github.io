# MDx Blocks

> Gutenberg blocks for MDx theme

MDx主题内置的Gutenberg区块源码

运行`npm run start`会监听src文件夹的任何修改操作并实时生成开发环境的代码

运行`npm run build`会生成用于生产环境的代码
